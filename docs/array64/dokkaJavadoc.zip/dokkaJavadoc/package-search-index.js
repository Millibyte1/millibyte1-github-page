var packageSearchIndex = [{"l":"io.github.millibyte1.array64","url":"io/github/millibyte1/array64/package-summary.html"}, {"l":"All packages","url":"index.html"}]
